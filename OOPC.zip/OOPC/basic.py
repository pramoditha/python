class item:
    def calculate(self,x,y):
        return x*y
item1=item()
item1.name="Iphone"
item1.price=40000
item1.quantity=5
print(type(item1))
print(item1.calculate(item1.price,item1.quantity))

item2=item()
item2.name="Samsung"
item2.price=4000
item2.quantity=6
print(type(item1))
print(item2.calculate(item2.price,item2.quantity))