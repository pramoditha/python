import csv

class Item:
    pay_rate = 0.8
    all = []
    
    def __init__(self, name: str, price, quantity=1):
        assert price >= 0, f"Price {price} is not greater than or equal to zero"
        
        self.name = name
        self.price = price
        self.quantity = quantity

        Item.all.append(self)

    def calculate(self):
        return self.price * self.quantity
    
    def apply_discount(self):
        self.price = self.price * self.pay_rate
    
    @classmethod
    def instantiate_from_csv(cls):
        file_path = r'D:\Python_L\OOPC\item.csv'
        try:
            with open(file_path, 'r') as f:
                reader = csv.DictReader(f)
                items = list(reader)
            
            for item_data in items:
                name = item_data.get('name')
                price = item_data.get('price')
                quantity = item_data.get('quantity')

                # Check if any required field is None or empty
                if name and price and quantity:
                    try:
                        cls(
                            name=name,
                            price=float(price),
                            quantity=int(quantity)
                        )
                    except ValueError as e:
                        print(f"Skipping row due to conversion error: {item_data}, {e}")
                else:
                    print(f"Skipping row due to missing data: {item_data}")
        
        except FileNotFoundError:
            print(f"The file at path {file_path} was not found.")
        except Exception as e:
            print(f"An error occurred: {e}")
    
    def __repr__(self):
        return f"Item('{self.name}', {self.price}, {self.quantity})"

# Call the class method to instantiate items from the CSV
Item.instantiate_from_csv()

# Print all instantiated items
print(Item.all)
