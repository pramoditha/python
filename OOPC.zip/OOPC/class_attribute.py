class item:
    pay_rate=0.8
    def __init__(self,name:str,price,quantity=1):
        
        assert price>=0 ,f"price {price} is nor greater than or equal to zero"
        self.name=name
        self.quantity=quantity
        self.price=price
item1=item("Iphone",1000)

item2=item("Samsung",1000,7)
item2.is_numpad=False
print(item.pay_rate)
print(item1.pay_rate)
print(item2.pay_rate)
print(item.__dict__)
print(item2.__dict__)