class item:
    def __init__(self,name:str,price,quantity=1):
        assert price>=0 ,f"price {price} is nor greater than or equal to zero"
        self.name=name
        self.quantity=quantity
        self.price=price
    def calculate(self):
        return self.price*self.quantity
item1=item("Iphone",-9)
print(item1.name)
print(item1.price)
print(item1.quantity)
print(item1.calculate())

item2=item("Samsung",3000,2)
item2.is_numpad=False
print(item2.name)
print(item2.price)
print(item2.quantity)
print(item2.calculate())