class item:
    pay_rate=0.8
    def __init__(self,name:str,price,quantity=1):
        
        assert price>=0 ,f"price {price} is nor greater than or equal to zero"
        
        self.name=name
        self.quantity=quantity
        self.price=price

    def calculate(self):
        return self.price*self.quantity
    def apply_discount(self):
        self.price=self.price*self.pay_rate

item1=item("Iphone",1000)
item2=item("Laptop",1000,3)
item1.apply_discount()
item2.pay_rate=0.7
item2.apply_discount()
print(item2.price)
print(item1.price)