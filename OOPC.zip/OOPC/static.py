class pra:
    @staticmethod
    def is_integer(num):
        print('yes')
ij=pra()
ij.is_integer(8)