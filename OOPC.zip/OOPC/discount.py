class item:
    pay_rate=0.8
    def __init__(self,name:str,price,quantity=1):
        
        assert price>=0 ,f"price {price} is nor greater than or equal to zero"
        
        self.name=name
        self.quantity=quantity
        self.price=price

    def calculate(self):
        return self.price*self.quantity
    def apply_discount(self):
        self.price=self.price*item.pay_rate

item1=item("Iphone",1000)

item1.apply_discount()
print(item1.price)


