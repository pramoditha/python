class item:
    pay_rate=0.8
    all=[]
    def __init__(self,name:str,price,quantity=1):
        
        assert price>=0 ,f"price {price} is nor greater than or equal to zero"
        
        self.name=name
        self.quantity=quantity
        self.price=price

        item.all.append(self)

    def calculate(self):
        return self.price*self.quantity
    def apply_discount(self):
        self.price=self.price*self.pay_rate

item1=item("Iphone",1000,1)
item2=item("Laptop",1000,3)
item3=item("Cable",10,35)
item4=item("Mouse",50,5)
item5=item("KeyboAard",75,5)
print(item.all)
for instance in item.all:
    print(instance.name) 
